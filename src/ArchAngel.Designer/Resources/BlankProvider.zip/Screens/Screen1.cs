using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace BlankProvider.Screens
{
    public partial class Screen1 : ArchAngel.Interfaces.Controls.ContentItems.ContentItem
    {
        public Screen1()
        {
            InitializeComponent();
            HelpFile = "My Provider.chm"; // Your .CHM help file, which must exist in the ArchAngel installation folder
            HelpPage = "Screen1.htm"; // The page in your help file that corresponds to this page
            Title = "Screen 1 Title"; // This is displayed in the navigation pane, and at the top of the screen with 'Step x - ' before it
            PageDescription = "Put your description here...";
        }

        /// <summary>
        /// Gets called when the user clicks the 'Next' button. Return false to cancel the action 
        /// and prevent the previous screen from being loaded.
        /// </summary>
        /// <returns></returns>
        public virtual bool Next()
        {
            return true;
        }

        /// <summary>
        /// Gets called when the user clicks the 'Back' button. Return false to cancel the action 
        /// and prevent the previous screen from being loaded.
        /// </summary>
        /// <returns></returns>
        public virtual bool Back()
        {
            return true;
        }


    }
}
