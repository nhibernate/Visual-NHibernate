using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace BlankProvider.Screens
{
    public partial class Screen2 : ArchAngel.Interfaces.Controls.ContentItems.ContentItem
    {
        public Screen2()
        {
            InitializeComponent();
            HelpFile = "My Provider.chm"; // Your chm help file
            HelpPage = "Screen2.htm"; // The page in your help file that corresponds to this page
            Title = "Screen 2 Title";
            PageDescription = "Put your description here...";
        }

        /// <summary>
        /// Gets called when the user clicks the 'Back' button. Return false to cancel the action 
        /// and prevent the previous screen from being loaded.
        /// </summary>
        /// <returns></returns>
        public override bool Back()
        {
            return true;
        }

        /// <summary>
        /// Gets called when the user clicks the 'Next' button. Return false to cancel the action 
        /// and prevent the previous screen from being loaded.
        /// </summary>
        /// <returns></returns>
        public override bool Next()
        {
            return base.Next();
        }

    }
}
