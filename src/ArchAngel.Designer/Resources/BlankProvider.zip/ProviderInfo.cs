using System;
using System.Collections.Generic;
using System.Text;
using ArchAngel.Interfaces;

namespace BlankProvider
{
    public class ProviderInfo : ArchAngel.Interfaces.ProviderInfo
    {
        public ProviderInfo()
        {
            this.Name = "My Provider";
            this.Description = "Default provider description.";

            // Add the screens in the order they should appear in ArchAngel Workbench
            this.Screens = new ArchAngel.Interfaces.Controls.ContentItems.ContentItem[2];
            this.Screens[0] = new Screens.Screen1();
            this.Screens[1] = new Screens.Screen2();
        }

        /// <summary>
        /// Saves this provider's state to a single file or multiple files in the specified folder.
        /// All files in the folder will be embedded within the .aaproj file. You can save the provider's
        /// data in any format you like, such as xml, binary serialization etc. What files you create and
        /// what you put inside them is totally up to you.
        /// </summary>
        /// <param name="folder">Folder to save the files to.</param>
        public override void Save(string folder)
        {
            // TODO: Add code to save this provider's state to file(s) in the specified folder.
        }

        /// <summary>
        /// Reads the page/object(s) state from file eg: xml, binary serialization etc
        /// </summary>
        /// <param name="folder">Folder to open files from.</param>
        public override void Open(string folder)
        {
            // TODO: Add code to populate this provider from the files saved in this folder by the Save() function in this class.
        }

        /// <summary>
        /// Perform any actions you need to just before analysis and generation begins.
        /// </summary>
        public override void PerformPreAnalysisActions()
        {
        }

        /// <summary>
        /// Returns whether this provider is in a valid state. This typically gets called just before generation.
        /// If false is returned, analysis and generation will not proceed.
        /// </summary>
        /// <param name="failReason">The reason for the invalid state.</param>
        /// <returns>True if the provider's state is valid, false otherwise.</returns>
        public override bool IsValid(out string failReason)
        {
            // TODO: Add code to determine whether this provider is in a valid state.
            failReason = "";
            return true;
        }

        /// <summary>
        /// Returns all objects of the specified type that currently exist in this provider. This typically gets called
        /// when analysis and generation begins and the objects get passed to the template to create the output files.
        /// </summary>
        /// <param name="typeName">Fully qualified name of the type of objects to return.</param>
        /// <returns>An arra of objects of the specified type.</returns>
        public override ArchAngel.Interfaces.IScriptBaseObject[] GetAllObjectsOfType(string typeName)
        {
            ArchAngel.Interfaces.IScriptBaseObject[] results = new ArchAngel.Interfaces.IScriptBaseObject[0];
            
            // TODO: Add code to return the requested objects in this provider.

            return results;
        }

        /// <summary>
        /// Clears all data from the provider. Gets called when opening projects or creating new projects.
        /// </summary>
        public override void Clear()
        {
            // TODO: Add code to Clear reset the object model to a clean state.
        }

        /// <summary>
        /// Gets a collection of objects that will be presented to the ArchAngel Designer user to select from
        /// when previewing a function. The object stack will be walked.
        /// </summary>
        public override object[] RootPreviewObjects
        {
            get
            {
                // TODO: Add code to return the objects.
                throw new Exception("The method or operation is not implemented.");
            }
        }

    }
}
